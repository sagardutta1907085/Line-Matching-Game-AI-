import time
import pygame
import numpy as np
from skfuzzy import control as ctrl
from LINE_MATCH.constants import PINK, WIDTH, HEIGHT, RED, WHITE
from LINE_MATCH.game import Game
from Minimax.minimax import minimax

FPS = 60

WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Match The Line")

def get_x_y_from_mouse(pos):
    mouse_x, mouse_y = pos
    positions = [(10, 10), (300, 20), (580, 20), (20, 300), (300, 300), (580, 300), (20, 580), (300, 580), (580, 580)]
    for idx, (x_range, y_range) in enumerate(positions):
        if mouse_x in range(x_range-10, x_range+30) and mouse_y in range(y_range-10, y_range+30):
            return divmod(idx, 3)
    return -1, -1

def fuzzy_evaluation(board):
    # Fuzzy variables
    occupancy = ctrl.Antecedent(np.arange(0, 10, 1), 'occupancy')
    proximity = ctrl.Antecedent(np.arange(0, 10, 1), 'proximity')
    score = ctrl.Consequent(np.arange(-10, 11, 1), 'score')

    # Fuzzy membership functions
    occupancy.automf(3)
    proximity.automf(3)
    score['low'] = ctrl.trapmf(score.universe, [-10, -10, -5, 0])
    score['medium'] = ctrl.trimf(score.universe, [-5, 0, 5])
    score['high'] = ctrl.trapmf(score.universe, [0, 5, 10, 10])

    # Fuzzy rules
    rule1 = ctrl.Rule(occupancy['poor'] & proximity['poor'], score['low'])
    rule2 = ctrl.Rule(occupancy['average'] & proximity['average'], score['medium'])
    rule3 = ctrl.Rule(occupancy['good'] & proximity['good'], score['high'])

    scoring_ctrl = ctrl.ControlSystem([rule1, rule2, rule3])
    scoring = ctrl.ControlSystemSimulation(scoring_ctrl)

    occupancy_value = np.random.randint(0, 10) 
    proximity_value = np.random.randint(0, 10)  

    scoring.input['occupancy'] = occupancy_value
    scoring.input['proximity'] = proximity_value

    scoring.compute()
    return scoring.output['score']

def display_message(screen, message):
    pygame.font.init()
    font = pygame.font.Font(None, 74)
    text = font.render(message, True, (0, 0, 0))
    text_rect = text.get_rect(center=(WIDTH / 2, HEIGHT / 2))
    screen.fill(WHITE) 
    screen.blit(text, text_rect)
    pygame.display.update()
    time.sleep(4)

def handle_winner(game, screen):
    winner = game.winner()
    if winner is not None:
        print(f"Winner detected: {winner}")  
        if winner == RED:
            display_message(screen, "You Won!")
        elif winner == PINK:
            game.update()  
            time.sleep(2) 
            display_message(screen, "Computer Won!")
        return True
    return False

def main():
    pygame.init()
    run = True
    clock = pygame.time.Clock()
    game = Game(WIN)

    while run:
        clock.tick(FPS)

        if game.turn == PINK:
            _, new_board = minimax(game.get_board(), depth=6, max_player=True, game=game)
            game.ai_move(new_board)
            game.update()

        if handle_winner(game, WIN):
            run = False
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            
            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                x_board, y_board = get_x_y_from_mouse(pos)
                if 0 <= x_board <= 2 and 0 <= y_board <= 2:
                    game.select(x_board, y_board)

        game.update()

    pygame.quit()

if __name__ == "__main__":
    main()
